
<script>
    function fun()
    {
        document.getElementById("username").valve = ";"
    document.getElementById("password").valve=";"

    }
</script>

    <form name="myform" onsubmit="return validateForm() method=" post" required;" >
        <label>
            <for =" username"> Username:</label><br>
            <input type="username" id=" username" name="username"><br></br>

                <label>

                    <for ="password"> password:</label><br>
                    <input type="password" id=" password" name="password"><br></br>
                        <input onclick="fun()" type="submit" valve="submit">
          </form>
      </label>
      </html>


